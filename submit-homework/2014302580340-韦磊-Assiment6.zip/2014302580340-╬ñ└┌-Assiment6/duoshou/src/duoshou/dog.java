package duoshou;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.io.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.swing.*;

;

public class dog extends JFrame implements ActionListener {
	private float balance = 0;

	public static void main(String args[]) {

		dog gui = new dog();
		gui.setSize(400, 300);
		gui.setLocation(400, 300);
		gui.setTitle("����֮��");
		gui.setVisible(true);
		// ATM atm=new ATM();
		// atmgui.atm.run();
		// atmgui.setResizable(false);;
		gui.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}

	Container c = getContentPane();
	JPanel p1 = new JPanel();
	JPanel p2 = new JPanel();
	JPanel p3 = new JPanel();
	JPanel p4 = new JPanel();
	JTextArea text = new JTextArea();
	JTextArea text1 = new JTextArea();
	TextField t1 = new TextField(40);
	TextField t2 = new TextField(40);
	TextField t3 = new TextField(120);
	

	JButton b0 = new JButton("�۸�");
	JButton b1 = new JButton("ÿ�γ�ֵ�Ľ��");
	JButton b2 = new JButton("��ֵ�����˺ű�");
	JButton b3 = new JButton("����");
	JButton b4 = new JButton("���");
	JButton b5 = new JButton("�鿴��������");
	

	public dog() {

		setLayout(new FlowLayout(FlowLayout.LEFT));
		add(b0);
		add(b1);
		add(b2);
		add(b3);
		add(b4);
		add(b5);
		
		// add(text);
		add(t1);
		add(t2);
		add(t3);
		t1.setText("");
		t2.setText("");
		t3.setText("");

		b0.addActionListener(this);

		b1.addActionListener(this);

		b2.addActionListener(this);

		b3.addActionListener(this);

		b4.addActionListener(this);

		b5.addActionListener(this);

		

	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if (e.getActionCommand() == b0.getText()) {
			t2.setText("100");

		}
		if (e.getActionCommand() == b1.getText()) {
			t2.setText("200");

		}
		if (e.getActionCommand() == b4.getText()) {
			t2.setText("��" + String.valueOf(balance));

		}
		if (e.getActionCommand() == b3.getText()) {
			if (Float.parseFloat(t2.getText()) > balance) {
				t2.setText("�������˿ûǮ��");
			} else {
				balance -= Float.parseFloat(t2.getText());
			}
			// t2.setText(String.valueOf(balance));

		}
		if (e.getActionCommand() == b2.getText()) {

			{
				balance += Float.parseFloat(t2.getText());
			}
			// t2.setText(String.valueOf(balance));

		}
		if (e.getActionCommand() == b5.getText()) {

			{
				t3.setText("ѧ�����л���԰Ȯ�����ܣ����ң���ܣ�ҧ�ˣ����ȣ�����ȫ��");
			}
			// t2.setText(String.valueOf(balance));

		}
		try{
			Connection conn=null;
			Class.forName("com.mysql.jdbc.Driver");
			conn=DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/my_schema?user=root&password=123456");
			System.out.println("yes");
			Statement stmt=conn.createStatement();
			String selectSql="SELECT*FROM professor_info";
			ResultSet selectResult=stmt.executeQuery(selectSql);
			
		   
		    
		}catch(Exception e1){
			System.out.println("MYSQL ERROR"+e1.getMessage());
			}
	}
}