package duoshou;

import java.awt.EventQueue;

import javax.swing.JButton;

import java.awt.Color;
import java.awt.Font; 

import javax.swing.JFrame;
import javax.swing.JPanel;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import javax.swing.border.EmptyBorder;

public class GUI extends JFrame {

	private JPanel contentPane;

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					GUI frame = new GUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public GUI() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(200, 200, 500, 500);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(10, 10, 10, 10));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JButton Cat = new JButton("cat");
		Cat.setBounds(0, 150, 100, 100);

		Cat.setFont(new Font("����", Font.BOLD | Font.ITALIC, 20));

		Cat.setBackground(Color.RED);
		Cat.setForeground(Color.BLACK);
		Cat.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				GUI p = new GUI();
				p.setVisible(false);
				cat c = new cat();
				c.setVisible(true);
			}
		});
		contentPane.add(Cat);

		JButton Dog = new JButton("dog");
		Dog.setBounds(0, 0, 100, 100);
		Dog.setFont(new Font("����", Font.BOLD | Font.ITALIC, 20));
		Dog.setBackground(Color.RED);
		Dog.setForeground(Color.BLACK);
		Dog.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				GUI g = new GUI();
				g.setVisible(false);
				dog d = new dog();
				d.setVisible(true);
			}
		});
		contentPane.add(Dog);

		JButton Snake = new JButton("sanke");
		Snake.setBounds(300, 0, 100, 100);
		Snake.setFont(new Font("����", Font.BOLD | Font.ITALIC, 20));
		Snake.setBackground(Color.RED);
		Snake.setForeground(Color.BLACK);

		Snake.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				GUI g = new GUI();
				g.setVisible(false);
				snake s = new snake();
				s.setVisible(true);
			}
		});
		contentPane.add(Snake);
	/*	public class yonghu {
			 String name;
			 float money=0f;
			 static String shopInfo="";
			 static float price=0;
			 int number=0;
			 static float summoney=0;
			public yonghu(String user)
			{
				name=user;
				shopInfo="";
				summoney=0f;
			}
			//�����
			public boolean buy(float price)
			{
				
				if((money-summoney)>=0f)
				{
					money=money-summoney;
					return true;
				}
				return false;
				
			}

			public String getName()
			{
				return name;
			}

			public void setmoney(float b)
			{
				money=money+b;
			}
			
			public void shopping(String name)
			{	shopInfo=shopInfo+ name+"\n";
			}

			public void Price(float price,int number)
			{
				summoney=price*number;
			}

			public float getMoney()
			{
				return money;
			}
			
			
		}*/
		JButton Fish = new JButton("fish");
		Fish.setBounds(150, 150, 100, 100);
		Fish.setFont(new Font("����", Font.BOLD | Font.ITALIC, 20));
		Fish.setBackground(Color.RED);
		Fish.setForeground(Color.BLACK);

		Fish.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				GUI g = new GUI();
				g.setVisible(false);
				fish f1 = new fish();
				f1.setVisible(true);
			}
		});
		contentPane.add(Fish);

		JButton Spider = new JButton("spider");
		Spider.setBounds(300, 150, 100, 100);
		Spider.setFont(new Font("����", Font.BOLD | Font.ITALIC, 20));
		Spider.setBackground(Color.RED);
		Spider.setForeground(Color.BLACK);

		Spider.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				GUI g = new GUI();
				g.setVisible(false);
				spider sp = new spider();
				sp.setVisible(true);
			}
		});
		contentPane.add(Spider);

	}
}
