package duoshou;

public class yonghu {
	 String name;
	 float money=0f;
	 static String shopInfo="";
	 static float price=0;
	 int number=0;
	 static float summoney=0;
	public yonghu(String user)
	{
		name=user;
		shopInfo="";
		summoney=0f;
	}
	//�����
	public boolean buy(float price)
	{
		
		if((money-summoney)>=0f)
		{
			money=money-summoney;
			return true;
		}
		return false;
		
	}

	public String getName()
	{
		return name;
	}

	public void setmoney(float b)
	{
		money=money+b;
	}
	
	public void shopping(String name)
	{	shopInfo=shopInfo+ name+"\n";
	}

	public void Price(float price,int number)
	{
		summoney=price*number;
	}

	public float getMoney()
	{
		return money;
	}
	
	
}



